### Hexlet tests and linter status:
Installation:
Create a virtual environment and install the distribution using the command pip install git+https://github.com/Scarecrow2510/python-project-49


[![Actions Status](https://github.com/Scarecrow2510/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Scarecrow2510/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/33b0714d6037921a4e61/maintainability)](https://codeclimate.com/github/Scarecrow2510/python-project-49/maintainability)

https://asciinema.org/a/xOKBSZHiksQtMouitMdoSCqjU   #brain-even

https://asciinema.org/a/MOQJ8OcBmmXO5XdkjHVg7CYv3   #brain-calc

https://asciinema.org/a/eiCtjxIQR7CDFU8EUtPCVNNWc   #brain-gcd

https://asciinema.org/a/El9KKDYC9wcG1OTZsUBzLPh6Q   #brain-progression

https://asciinema.org/a/V00PVSqmFerj0PyJRWwkFSPfY   #brain-prime
