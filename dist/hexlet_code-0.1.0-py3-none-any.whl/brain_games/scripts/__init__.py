"""Brain-games scripts."""
